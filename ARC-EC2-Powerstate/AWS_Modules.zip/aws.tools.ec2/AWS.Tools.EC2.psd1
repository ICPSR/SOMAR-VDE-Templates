#
# Module manifest for module 'AWS.Tools.EC2'
#

@{
    # Script module or binary module file associated with this manifest
    RootModule = 'AWS.Tools.EC2.dll'

    # Supported PSEditions
    CompatiblePSEditions = @('Core', 'Desktop')

    # Version number of this module.
    ModuleVersion = '4.1.14.0'

    # ID used to uniquely identify this module
    GUID = 'beb2445c-fd90-4fda-adf1-f8c955ce16dc'

    # Author of this module
    Author = 'Amazon.com, Inc'

    # Company or vendor of this module
    CompanyName = 'Amazon.com, Inc'

    # Copyright statement for this module
    Copyright = 'Copyright 2012-2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.'

    # Description of the functionality provided by this module
    Description = 'The EC2 module of AWS Tools for PowerShell lets developers and administrators manage Amazon Elastic Compute Cloud (EC2) from the PowerShell scripting environment. In order to manage each AWS service, install the corresponding module (e.g. AWS.Tools.EC2, AWS.Tools.S3...).
The module AWS.Tools.Installer (https://www.powershellgallery.com/packages/AWS.Tools.Installer/) makes it easier to install, update and uninstall the AWS.Tools modules.
This version of AWS Tools for PowerShell is compatible with Windows PowerShell 5.1+ and PowerShell Core 6+ on Windows, Linux and macOS. When running on Windows PowerShell, .NET Framework 4.7.2 or newer is required. Alternative modules AWSPowerShell.NetCore and AWSPowerShell, provide support for all AWS services from a single module and also support older versions of Windows PowerShell and .NET Framework.'

    # Minimum version of the PowerShell engine required by this module
    PowerShellVersion = '5.1'

    # Name of the PowerShell host required by this module
    PowerShellHostName = ''

    # Minimum version of the PowerShell host required by this module
    PowerShellHostVersion = ''

    # Minimum version of the .NET Framework required by this module
    DotNetFrameworkVersion = '4.7.2'

    # Minimum version of the common language runtime (CLR) required by this module
    CLRVersion = ''

    # Processor architecture (None, X86, Amd64, IA64) required by this module
    ProcessorArchitecture = ''

    # Modules that must be imported into the global environment prior to importing this module
    RequiredModules = @(
        @{
            ModuleName = 'AWS.Tools.Common';
            RequiredVersion = '4.1.14.0';
            Guid = 'e5b05bf3-9eee-47b2-81f2-41ddc0501b86' }
    )

    # Assemblies that must be loaded prior to importing this module.
    RequiredAssemblies = @(
        'AWSSDK.EC2.dll'
    )

    # Script files (.ps1) that are run in the caller's environment prior to importing this module
    ScriptsToProcess = @(

    )

    # Type files (.ps1xml) to be loaded when importing this module
    TypesToProcess = @(

    )

    # Format files (.ps1xml) to be loaded when importing this module
#    FormatsToProcess = @(
#        'AWS.Tools.EC2.Format.ps1xml'
#    )

    # Modules to import as nested modules of the module specified in ModuleToProcess
#    NestedModules = @(
#        'AWS.Tools.EC2.Completers.psm1',
#        'AWS.Tools.EC2.Aliases.psm1'
#    )

    # Functions to export from this module
    FunctionsToExport = ''

    # Cmdlets to export from this module
    CmdletsToExport = @(
        'Add-EC2CapacityReservation', 
        'Add-EC2ClassicLinkVpc', 
        'Add-EC2InternetGateway', 
        'Add-EC2NetworkInterface', 
        'Add-EC2SecurityGroupToClientVpnTargetNetwork', 
        'Add-EC2Volume', 
        'Add-EC2VpnGateway', 
        'Approve-EC2EndpointConnection', 
        'Approve-EC2ReservedInstancesExchangeQuote', 
        'Approve-EC2TransitGatewayMulticastDomainAssociation', 
        'Approve-EC2TransitGatewayPeeringAttachment', 
        'Approve-EC2TransitGatewayVpcAttachment', 
        'Approve-EC2VpcPeeringConnection', 
        'Confirm-EC2ProductInstance', 
        'Copy-EC2FpgaImage', 
        'Copy-EC2Image', 
        'Copy-EC2Snapshot', 
        'Deny-EC2EndpointConnection', 
        'Deny-EC2TransitGatewayMulticastDomainAssociation', 
        'Deny-EC2TransitGatewayPeeringAttachment', 
        'Deny-EC2TransitGatewayVpcAttachment', 
        'Deny-EC2VpcPeeringConnection', 
        'Disable-EC2EbsEncryptionByDefault', 
        'Disable-EC2FastSnapshotRestore', 
        'Disable-EC2ImageDeprecation', 
        'Disable-EC2SerialConsoleAccess', 
        'Disable-EC2TransitGatewayRouteTablePropagation', 
        'Disable-EC2VgwRoutePropagation', 
        'Disable-EC2VpcClassicLink', 
        'Disable-EC2VpcClassicLinkDnsSupport', 
        'Dismount-EC2ClassicLinkVpc', 
        'Dismount-EC2InternetGateway', 
        'Dismount-EC2NetworkInterface', 
        'Dismount-EC2Volume', 
        'Dismount-EC2VpnGateway', 
        'Edit-EC2AddressAttribute', 
        'Edit-EC2AvailabilityZoneGroup', 
        'Edit-EC2CapacityReservation', 
        'Edit-EC2ClientVpnEndpoint', 
        'Edit-EC2DefaultCreditSpecification', 
        'Edit-EC2EbsDefaultKmsKeyId', 
        'Edit-EC2EndpointServicePermission', 
        'Edit-EC2Fleet', 
        'Edit-EC2FpgaImageAttribute', 
        'Edit-EC2Host', 
        'Edit-EC2IdentityIdFormat', 
        'Edit-EC2IdFormat', 
        'Edit-EC2ImageAttribute', 
        'Edit-EC2InstanceAttribute', 
        'Edit-EC2InstanceCapacityReservationAttribute', 
        'Edit-EC2InstanceCreditSpecification', 
        'Edit-EC2InstanceEventStartTime', 
        'Edit-EC2InstanceMetadataOption', 
        'Edit-EC2InstancePlacement', 
        'Edit-EC2LaunchTemplate', 
        'Edit-EC2ManagedPrefixList', 
        'Edit-EC2NetworkInterfaceAttribute', 
        'Edit-EC2ReservedInstance', 
        'Edit-EC2SnapshotAttribute', 
        'Edit-EC2SpotFleetRequest', 
        'Edit-EC2SubnetAttribute', 
        'Edit-EC2TrafficMirrorFilterNetworkService', 
        'Edit-EC2TrafficMirrorFilterRule', 
        'Edit-EC2TrafficMirrorSession', 
        'Edit-EC2TransitGateway', 
        'Edit-EC2TransitGatewayPrefixListReference', 
        'Edit-EC2TransitGatewayVpcAttachment', 
        'Edit-EC2Volume', 
        'Edit-EC2VolumeAttribute', 
        'Edit-EC2VpcAttribute', 
        'Edit-EC2VpcEndpoint', 
        'Edit-EC2VpcEndpointConnectionNotification', 
        'Edit-EC2VpcEndpointServiceConfiguration', 
        'Edit-EC2VpcPeeringConnectionOption', 
        'Edit-EC2VpcTenancy', 
        'Edit-EC2VpnConnection', 
        'Edit-EC2VpnConnectionOption', 
        'Edit-EC2VpnTunnelCertificate', 
        'Edit-EC2VpnTunnelOption', 
        'Enable-EC2EbsEncryptionByDefault', 
        'Enable-EC2FastSnapshotRestore', 
        'Enable-EC2ImageDeprecation', 
        'Enable-EC2SerialConsoleAccess', 
        'Enable-EC2TransitGatewayRouteTablePropagation', 
        'Enable-EC2VgwRoutePropagation', 
        'Enable-EC2VolumeIO', 
        'Enable-EC2VpcClassicLink', 
        'Enable-EC2VpcClassicLinkDnsSupport', 
        'Export-EC2ClientVpnClientCertificateRevocationList', 
        'Export-EC2ClientVpnClientConfiguration', 
        'Export-EC2Image', 
        'Export-EC2TransitGatewayRoute', 
        'Get-EC2AccountAttribute', 
        'Get-EC2Address', 
        'Get-EC2AddressesAttribute', 
        'Get-EC2AggregateIdFormat', 
        'Get-EC2AssociatedEnclaveCertificateIamRole', 
        'Get-EC2AssociatedIpv6PoolCidr', 
        'Get-EC2AvailabilityZone', 
        'Get-EC2BundleTask', 
        'Get-EC2ByoipCidr', 
        'Get-EC2CapacityReservation', 
        'Get-EC2CapacityReservationUsage', 
        'Get-EC2CarrierGateway', 
        'Get-EC2ClassicLinkInstance', 
        'Get-EC2ClientVpnAuthorizationRule', 
        'Get-EC2ClientVpnConnection', 
        'Get-EC2ClientVpnEndpoint', 
        'Get-EC2ClientVpnRoute', 
        'Get-EC2ClientVpnTargetNetwork', 
        'Get-EC2CoipPool', 
        'Get-EC2CoipPoolUsage', 
        'Get-EC2ConsoleOutput', 
        'Get-EC2ConsoleScreenshot', 
        'Get-EC2CreditSpecification', 
        'Get-EC2CustomerGateway', 
        'Get-EC2DefaultCreditSpecification', 
        'Get-EC2DhcpOption', 
        'Get-EC2EbsDefaultKmsKeyId', 
        'Get-EC2EbsEncryptionByDefault', 
        'Get-EC2EgressOnlyInternetGatewayList', 
        'Get-EC2ElasticGpu', 
        'Get-EC2EndpointConnection', 
        'Get-EC2EndpointConnectionNotification', 
        'Get-EC2EndpointServiceConfiguration', 
        'Get-EC2EndpointServicePermission', 
        'Get-EC2ExportImageTask', 
        'Get-EC2ExportTask', 
        'Get-EC2FastSnapshotRestore', 
        'Get-EC2FleetHistory', 
        'Get-EC2FleetInstanceList', 
        'Get-EC2FleetList', 
        'Get-EC2FlowLog', 
        'Get-EC2FlowLogsIntegrationTemplate', 
        'Get-EC2FpgaImage', 
        'Get-EC2FpgaImageAttribute', 
        'Get-EC2GroupsForCapacityReservation', 
        'Get-EC2Host', 
        'Get-EC2HostReservation', 
        'Get-EC2HostReservationOffering', 
        'Get-EC2HostReservationPurchasePreview', 
        'Get-EC2IamInstanceProfileAssociation', 
        'Get-EC2IdentityIdFormat', 
        'Get-EC2IdFormat', 
        'Get-EC2Image', 
        'Get-EC2ImageAttribute', 
        'Get-EC2ImageByName', 
        'Get-EC2ImportImageTask', 
        'Get-EC2ImportSnapshotTask', 
        'Get-EC2Instance', 
        'Get-EC2InstanceAttribute', 
        'Get-EC2InstanceEventNotificationAttribute', 
        'Get-EC2InstanceMetadata', 
        'Get-EC2InstanceStatus', 
        'Get-EC2InstanceType', 
        'Get-EC2InstanceTypeOffering', 
        'Get-EC2InternetGateway', 
        'Get-EC2Ipv6Pool', 
        'Get-EC2KeyPair', 
        'Get-EC2LaunchTemplateData', 
        'Get-EC2LocalGateway', 
        'Get-EC2LocalGatewayRouteTable', 
        'Get-EC2LocalGatewayRouteTableVirtualInterfaceGroupAssociation', 
        'Get-EC2LocalGatewayRouteTableVpcAssociation', 
        'Get-EC2LocalGatewayVirtualInterface', 
        'Get-EC2LocalGatewayVirtualInterfaceGroup', 
        'Get-EC2ManagedPrefixList', 
        'Get-EC2ManagedPrefixListAssociation', 
        'Get-EC2ManagedPrefixListEntry', 
        'Get-EC2MovingAddress', 
        'Get-EC2NatGateway', 
        'Get-EC2NetworkAcl', 
        'Get-EC2NetworkInsightsAnalysis', 
        'Get-EC2NetworkInsightsPath', 
        'Get-EC2NetworkInterface', 
        'Get-EC2NetworkInterfaceAttribute', 
        'Get-EC2NetworkInterfacePermission', 
        'Get-EC2PasswordData', 
        'Get-EC2PlacementGroup', 
        'Get-EC2PrefixList', 
        'Get-EC2PrincipalIdFormat', 
        'Get-EC2PublicIpv4Pool', 
        'Get-EC2Region', 
        'Get-EC2ReplaceRootVolumeTask', 
        'Get-EC2ReservedInstance', 
        'Get-EC2ReservedInstancesExchangeQuote', 
        'Get-EC2ReservedInstancesListing', 
        'Get-EC2ReservedInstancesModification', 
        'Get-EC2ReservedInstancesOffering', 
        'Get-EC2RouteTable', 
        'Get-EC2ScheduledInstance', 
        'Get-EC2ScheduledInstanceAvailability', 
        'Get-EC2SecurityGroup', 
        'Get-EC2SecurityGroupReference', 
        'Get-EC2SerialConsoleAccessStatus', 
        'Get-EC2Snapshot', 
        'Get-EC2SnapshotAttribute', 
        'Get-EC2SpotDatafeedSubscription', 
        'Get-EC2SpotFleetInstance', 
        'Get-EC2SpotFleetRequest', 
        'Get-EC2SpotFleetRequestHistory', 
        'Get-EC2SpotInstanceRequest', 
        'Get-EC2SpotPriceHistory', 
        'Get-EC2StaleSecurityGroup', 
        'Get-EC2StoreImageTask', 
        'Get-EC2Subnet', 
        'Get-EC2Tag', 
        'Get-EC2Template', 
        'Get-EC2TemplateVersion', 
        'Get-EC2TrafficMirrorFilter', 
        'Get-EC2TrafficMirrorSession', 
        'Get-EC2TrafficMirrorTarget', 
        'Get-EC2TransitGateway', 
        'Get-EC2TransitGatewayAttachment', 
        'Get-EC2TransitGatewayAttachmentPropagation', 
        'Get-EC2TransitGatewayConnect', 
        'Get-EC2TransitGatewayConnectPeer', 
        'Get-EC2TransitGatewayMulticastDomain', 
        'Get-EC2TransitGatewayMulticastDomainAssociation', 
        'Get-EC2TransitGatewayPeeringAttachment', 
        'Get-EC2TransitGatewayPrefixListReference', 
        'Get-EC2TransitGatewayRouteTable', 
        'Get-EC2TransitGatewayRouteTableAssociation', 
        'Get-EC2TransitGatewayRouteTablePropagation', 
        'Get-EC2TransitGatewayVpcAttachment', 
        'Get-EC2TrunkInterfaceAssociation', 
        'Get-EC2Volume', 
        'Get-EC2VolumeAttribute', 
        'Get-EC2VolumeModification', 
        'Get-EC2VolumeStatus', 
        'Get-EC2Vpc', 
        'Get-EC2VpcAttribute', 
        'Get-EC2VpcClassicLink', 
        'Get-EC2VpcClassicLinkDnsSupport', 
        'Get-EC2VpcEndpoint', 
        'Get-EC2VpcEndpointService', 
        'Get-EC2VpcPeeringConnection', 
        'Get-EC2VpnConnection', 
        'Get-EC2VpnGateway', 
        'Grant-EC2ClientVpnIngress', 
        'Grant-EC2SecurityGroupEgress', 
        'Grant-EC2SecurityGroupIngress', 
        'Import-EC2ClientVpnClientCertificateRevocationList', 
        'Import-EC2Image', 
        'Import-EC2KeyPair', 
        'Import-EC2Snapshot', 
        'Move-EC2AddressToVpc', 
        'New-EC2Address', 
        'New-EC2CarrierGateway', 
        'New-EC2ClientVpnEndpoint', 
        'New-EC2ClientVpnRoute', 
        'New-EC2CustomerGateway', 
        'New-EC2DefaultSubnet', 
        'New-EC2DefaultVpc', 
        'New-EC2DhcpOption', 
        'New-EC2EgressOnlyInternetGateway', 
        'New-EC2Fleet', 
        'New-EC2FlowLog', 
        'New-EC2FpgaImage', 
        'New-EC2Host', 
        'New-EC2HostReservation', 
        'New-EC2Image', 
        'New-EC2Instance', 
        'New-EC2InstanceBundle', 
        'New-EC2InstanceExportTask', 
        'New-EC2InternetGateway', 
        'New-EC2KeyPair', 
        'New-EC2LaunchTemplate', 
        'New-EC2LaunchTemplateVersion', 
        'New-EC2LocalGatewayRoute', 
        'New-EC2LocalGatewayRouteTableVpcAssociation', 
        'New-EC2ManagedPrefixList', 
        'New-EC2NatGateway', 
        'New-EC2NetworkAcl', 
        'New-EC2NetworkAclEntry', 
        'New-EC2NetworkInsightsPath', 
        'New-EC2NetworkInterface', 
        'New-EC2NetworkInterfacePermission', 
        'New-EC2PlacementGroup', 
        'New-EC2ReplaceRootVolumeTask', 
        'New-EC2ReservedInstance', 
        'New-EC2ReservedInstancesListing', 
        'New-EC2RestoreImageTask', 
        'New-EC2Route', 
        'New-EC2RouteTable', 
        'New-EC2ScheduledInstance', 
        'New-EC2ScheduledInstancePurchase', 
        'New-EC2SecurityGroup', 
        'New-EC2Snapshot', 
        'New-EC2SnapshotBatch', 
        'New-EC2SpotDatafeedSubscription', 
        'New-EC2StoreImageTask', 
        'New-EC2Subnet', 
        'New-EC2Tag', 
        'New-EC2TrafficMirrorFilter', 
        'New-EC2TrafficMirrorFilterRule', 
        'New-EC2TrafficMirrorSession', 
        'New-EC2TrafficMirrorTarget', 
        'New-EC2TransitGateway', 
        'New-EC2TransitGatewayConnect', 
        'New-EC2TransitGatewayConnectPeer', 
        'New-EC2TransitGatewayMulticastDomain', 
        'New-EC2TransitGatewayPeeringAttachment', 
        'New-EC2TransitGatewayPrefixListReference', 
        'New-EC2TransitGatewayRoute', 
        'New-EC2TransitGatewayRouteTable', 
        'New-EC2TransitGatewayVpcAttachment', 
        'New-EC2Volume', 
        'New-EC2Vpc', 
        'New-EC2VpcEndpoint', 
        'New-EC2VpcEndpointConnectionNotification', 
        'New-EC2VpcEndpointServiceConfiguration', 
        'New-EC2VpcPeeringConnection', 
        'New-EC2VpnConnection', 
        'New-EC2VpnConnectionRoute', 
        'New-EC2VpnGateway', 
        'Register-EC2Address', 
        'Register-EC2ByoipCidr', 
        'Register-EC2ClientVpnTargetNetwork', 
        'Register-EC2DhcpOption', 
        'Register-EC2EnclaveCertificateIamRole', 
        'Register-EC2IamInstanceProfile', 
        'Register-EC2Image', 
        'Register-EC2InstanceEventNotificationAttribute', 
        'Register-EC2Ipv6AddressList', 
        'Register-EC2PrivateIpAddress', 
        'Register-EC2RouteTable', 
        'Register-EC2SubnetCidrBlock', 
        'Register-EC2TransitGatewayMulticastDomain', 
        'Register-EC2TransitGatewayMulticastGroupMember', 
        'Register-EC2TransitGatewayMulticastGroupSource', 
        'Register-EC2TransitGatewayRouteTable', 
        'Register-EC2TrunkInterface', 
        'Register-EC2VpcCidrBlock', 
        'Remove-EC2Address', 
        'Remove-EC2CapacityReservation', 
        'Remove-EC2CarrierGateway', 
        'Remove-EC2ClientVpnEndpoint', 
        'Remove-EC2ClientVpnRoute', 
        'Remove-EC2CustomerGateway', 
        'Remove-EC2DhcpOption', 
        'Remove-EC2EgressOnlyInternetGateway', 
        'Remove-EC2EndpointConnectionNotification', 
        'Remove-EC2EndpointServiceConfiguration', 
        'Remove-EC2Fleet', 
        'Remove-EC2FlowLog', 
        'Remove-EC2FpgaImage', 
        'Remove-EC2Host', 
        'Remove-EC2Instance', 
        'Remove-EC2InternetGateway', 
        'Remove-EC2KeyPair', 
        'Remove-EC2LaunchTemplate', 
        'Remove-EC2LocalGatewayRoute', 
        'Remove-EC2LocalGatewayRouteTableVpcAssociation', 
        'Remove-EC2ManagedPrefixList', 
        'Remove-EC2NatGateway', 
        'Remove-EC2NetworkAcl', 
        'Remove-EC2NetworkAclEntry', 
        'Remove-EC2NetworkInsightsAnalysis', 
        'Remove-EC2NetworkInsightsPath', 
        'Remove-EC2NetworkInterface', 
        'Remove-EC2NetworkInterfacePermission', 
        'Remove-EC2PlacementGroup', 
        'Remove-EC2QueuedReservedInstance', 
        'Remove-EC2Route', 
        'Remove-EC2RouteTable', 
        'Remove-EC2SecurityGroup', 
        'Remove-EC2Snapshot', 
        'Remove-EC2SpotDatafeedSubscription', 
        'Remove-EC2Subnet', 
        'Remove-EC2Tag', 
        'Remove-EC2TemplateVersion', 
        'Remove-EC2TrafficMirrorFilter', 
        'Remove-EC2TrafficMirrorFilterRule', 
        'Remove-EC2TrafficMirrorSession', 
        'Remove-EC2TrafficMirrorTarget', 
        'Remove-EC2TransitGateway', 
        'Remove-EC2TransitGatewayConnect', 
        'Remove-EC2TransitGatewayConnectPeer', 
        'Remove-EC2TransitGatewayMulticastDomain', 
        'Remove-EC2TransitGatewayPeeringAttachment', 
        'Remove-EC2TransitGatewayPrefixListReference', 
        'Remove-EC2TransitGatewayRoute', 
        'Remove-EC2TransitGatewayRouteTable', 
        'Remove-EC2TransitGatewayVpcAttachment', 
        'Remove-EC2Volume', 
        'Remove-EC2Vpc', 
        'Remove-EC2VpcEndpoint', 
        'Remove-EC2VpcPeeringConnection', 
        'Remove-EC2VpnConnection', 
        'Remove-EC2VpnConnectionRoute', 
        'Remove-EC2VpnGateway', 
        'Request-EC2SpotFleet', 
        'Request-EC2SpotInstance', 
        'Reset-EC2AddressAttribute', 
        'Reset-EC2EbsDefaultKmsKeyId', 
        'Reset-EC2FpgaImageAttribute', 
        'Reset-EC2ImageAttribute', 
        'Reset-EC2InstanceAttribute', 
        'Reset-EC2NetworkInterfaceAttribute', 
        'Reset-EC2SnapshotAttribute', 
        'Restart-EC2Instance', 
        'Restore-EC2AddressToClassic', 
        'Restore-EC2ManagedPrefixListVersion', 
        'Revoke-EC2ClientVpnIngress', 
        'Revoke-EC2SecurityGroupEgress', 
        'Revoke-EC2SecurityGroupIngress', 
        'Search-EC2LocalGatewayRoute', 
        'Search-EC2TransitGatewayMulticastGroup', 
        'Search-EC2TransitGatewayRoute', 
        'Send-EC2DiagnosticInterrupt', 
        'Send-EC2InstanceStatus', 
        'Set-EC2IamInstanceProfileAssociation', 
        'Set-EC2NetworkAclAssociation', 
        'Set-EC2NetworkAclEntry', 
        'Set-EC2Route', 
        'Set-EC2RouteTableAssociation', 
        'Set-EC2TransitGatewayRoute', 
        'Start-EC2ByoipCidrAdvertisement', 
        'Start-EC2Instance', 
        'Start-EC2InstanceMonitoring', 
        'Start-EC2NetworkInsightsAnalysis', 
        'Start-EC2VpcEndpointServicePrivateDnsVerification', 
        'Stop-EC2BundleTask', 
        'Stop-EC2ByoipCidrAdvertisement', 
        'Stop-EC2ClientVpnConnection', 
        'Stop-EC2ExportTask', 
        'Stop-EC2ImportTask', 
        'Stop-EC2Instance', 
        'Stop-EC2InstanceMonitoring', 
        'Stop-EC2ReservedInstancesListing', 
        'Stop-EC2SpotFleetRequest', 
        'Stop-EC2SpotInstanceRequest', 
        'Unregister-EC2Address', 
        'Unregister-EC2ByoipCidr', 
        'Unregister-EC2ClientVpnTargetNetwork', 
        'Unregister-EC2EnclaveCertificateIamRole', 
        'Unregister-EC2IamInstanceProfile', 
        'Unregister-EC2Image', 
        'Unregister-EC2InstanceEventNotificationAttribute', 
        'Unregister-EC2Ipv6AddressList', 
        'Unregister-EC2PrivateIpAddress', 
        'Unregister-EC2RouteTable', 
        'Unregister-EC2SubnetCidrBlock', 
        'Unregister-EC2TransitGatewayMulticastDomain', 
        'Unregister-EC2TransitGatewayMulticastGroupMember', 
        'Unregister-EC2TransitGatewayMulticastGroupSource', 
        'Unregister-EC2TransitGatewayRouteTable', 
        'Unregister-EC2TrunkInterface', 
        'Unregister-EC2VpcCidrBlock', 
        'Update-EC2SecurityGroupRuleEgressDescription', 
        'Update-EC2SecurityGroupRuleIngressDescription')

    # Variables to export from this module
    VariablesToExport = '*'

    # Aliases to export from this module
    AliasesToExport = @(
        'Confirm-EC2ReservedInstancesExchangeQuote', 
        'Confirm-EC2TransitGatewayPeeringAttachment', 
        'Confirm-EC2TransitGatewayVpcAttachment', 
        'Confirm-EC2EndpointConnection', 
        'Confirm-EC2VpcPeeringConnection', 
        'New-EC2Hosts', 
        'New-EC2FlowLogs', 
        'Remove-EC2FlowLogs', 
        'Get-EC2AccountAttributes', 
        'Get-EC2ExportTasks', 
        'Get-EC2FlowLogs', 
        'Get-EC2Hosts', 
        'Get-EC2ReservedInstancesModifications', 
        'Get-EC2Snapshots', 
        'Get-EC2VpcPeeringConnections', 
        'Edit-EC2Hosts', 
        'ReleaseHosts')

    # List of all modules packaged with this module
    ModuleList = @()

    # List of all files packaged with this module
    FileList = @(
        'AWS.Tools.EC2.dll-Help.xml'
    )

    # Private data to pass to the module specified in ModuleToProcess
    PrivateData = @{

        PSData = @{
            Tags = @('AWS', 'cloud', 'Windows', 'PSEdition_Desktop', 'PSEdition_Core', 'Linux', 'MacOS', 'Mac')
            LicenseUri = 'https://aws.amazon.com/apache-2-0/'
            ProjectUri = 'https://github.com/aws/aws-tools-for-powershell'
            IconUri = 'https://sdk-for-net.amazonwebservices.com/images/AWSLogo128x128.png'
            ReleaseNotes = 'https://github.com/aws/aws-tools-for-powershell/blob/master/CHANGELOG.md'
        }
    }
}

# SIG # Begin signature block
# MIIa4gYJKoZIhvcNAQcCoIIa0zCCGs8CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCuyU5BXqIBfLWf
# FIw5dmEr9XlF/AIybdruJdBkcjWP6qCCCoYwggUwMIIEGKADAgECAhAECRgbX9W7
# ZnVTQ7VvlVAIMA0GCSqGSIb3DQEBCwUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0xMzEwMjIxMjAwMDBa
# Fw0yODEwMjIxMjAwMDBaMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lD
# ZXJ0IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0EwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQD407Mcfw4Rr2d3B9MLMUkZz9D7RZmxOttE9X/l
# qJ3bMtdx6nadBS63j/qSQ8Cl+YnUNxnXtqrwnIal2CWsDnkoOn7p0WfTxvspJ8fT
# eyOU5JEjlpB3gvmhhCNmElQzUHSxKCa7JGnCwlLyFGeKiUXULaGj6YgsIJWuHEqH
# CN8M9eJNYBi+qsSyrnAxZjNxPqxwoqvOf+l8y5Kh5TsxHM/q8grkV7tKtel05iv+
# bMt+dDk2DZDv5LVOpKnqagqrhPOsZ061xPeM0SAlI+sIZD5SlsHyDxL0xY4PwaLo
# LFH3c7y9hbFig3NBggfkOItqcyDQD2RzPJ6fpjOp/RnfJZPRAgMBAAGjggHNMIIB
# yTASBgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAK
# BggrBgEFBQcDAzB5BggrBgEFBQcBAQRtMGswJAYIKwYBBQUHMAGGGGh0dHA6Ly9v
# Y3NwLmRpZ2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3aHR0cDovL2NhY2VydHMuZGln
# aWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNydDCBgQYDVR0fBHow
# eDA6oDigNoY0aHR0cDovL2NybDQuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJl
# ZElEUm9vdENBLmNybDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0Rp
# Z2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDBPBgNVHSAESDBGMDgGCmCGSAGG/WwA
# AgQwKjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAK
# BghghkgBhv1sAzAdBgNVHQ4EFgQUWsS5eyoKo6XqcQPAYPkt9mV1DlgwHwYDVR0j
# BBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wDQYJKoZIhvcNAQELBQADggEBAD7s
# DVoks/Mi0RXILHwlKXaoHV0cLToaxO8wYdd+C2D9wz0PxK+L/e8q3yBVN7Dh9tGS
# dQ9RtG6ljlriXiSBThCk7j9xjmMOE0ut119EefM2FAaK95xGTlz/kLEbBw6RFfu6
# r7VRwo0kriTGxycqoSkoGjpxKAI8LpGjwCUR4pwUR6F6aGivm6dcIFzZcbEMj7uo
# +MUSaJ/PQMtARKUT8OZkDCUIQjKyNookAv4vcn4c10lFluhZHen6dGRrsutmQ9qz
# sIzV6Q3d9gEgzpkxYz0IGhizgZtPxpMQBvwHgfqL2vmCSfdibqFT+hKUGIUukpHq
# aGxEMrJmoecYpJpkUe8wggVOMIIENqADAgECAhALTIJyAKtH3xTtbI8ZUVgmMA0G
# CSqGSIb3DQEBCwUAMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0
# IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0EwHhcNMjAwNjIyMDAwMDAw
# WhcNMjEwNjMwMTIwMDAwWjCBijELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1NlYXR0bGUxIjAgBgNVBAoTGUFtYXpvbiBXZWIgU2Vy
# dmljZXMsIEluYy4xDDAKBgNVBAsTA0FXUzEiMCAGA1UEAxMZQW1hem9uIFdlYiBT
# ZXJ2aWNlcywgSW5jLjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALmr
# sFGrSta/FARlw23GEH+EpVCu0ejJBCgyuE2cX1ArId8rh8M6Q9/R8mlash12LDk6
# Zhfl0418bvsGqxp4V7x1PBwM9LqHwv+v9SRNJkIIRE9XQW5XLubMLDSZbqz4ysK4
# BeNXx8fg3DPIhzRYnNVAsINj43T95kW21Mje7pe8nABgUF+ihOyarccQ/+eUYHbf
# vNKEn7jVwVElzKc0zlYB2xwn6NC75FunB9ah9bK1eiKyDIVq0lQfW07yW4ReAIci
# 7Lmk/NLK6p+WX18tevZyOZvTp2JWCMrjQpi4Z6zNcgPVlQH/Fw9pOH88AoRNspJq
# M4cTQ9nZuVO1YP37uh8CAwEAAaOCAcUwggHBMB8GA1UdIwQYMBaAFFrEuXsqCqOl
# 6nEDwGD5LfZldQ5YMB0GA1UdDgQWBBRslc5x8VXQyhHcfVS3bCh5Tu1ZcTAOBgNV
# HQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwdwYDVR0fBHAwbjA1oDOg
# MYYvaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL3NoYTItYXNzdXJlZC1jcy1nMS5j
# cmwwNaAzoDGGL2h0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9zaGEyLWFzc3VyZWQt
# Y3MtZzEuY3JsMEwGA1UdIARFMEMwNwYJYIZIAYb9bAMBMCowKAYIKwYBBQUHAgEW
# HGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwCAYGZ4EMAQQBMIGEBggrBgEF
# BQcBAQR4MHYwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBO
# BggrBgEFBQcwAoZCaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# U0hBMkFzc3VyZWRJRENvZGVTaWduaW5nQ0EuY3J0MAwGA1UdEwEB/wQCMAAwDQYJ
# KoZIhvcNAQELBQADggEBAIyDXLu8ZDZqNX5ET8VHvAu/9V6yXI+HNMeUOJO4/az7
# 5HmJmja6SpmfLZC3g+WbNgF4roHwMNsIdb7dbdTGedxef49HJe5Ut5iV5vQ8DuKn
# PA7ezZV93Y5XDEiboX3sys5/k+7B1ZcP1jkObnfzQs7QXLAa3C/+kPtNmsXmTFOg
# DzRBmkr1Z/LXGTxgoWNQVZKNm2HA6ePRLPGBIXw7DUTnHtr9+4Fqxadck6fn5izz
# PUMOliRngw8XKTIRgBODRInHJZN9GRZI11emCP25LdHwLySxdHBTKsaslToKRAnd
# hrQhoc1FDAV6wKBOQoEKRZd75GIijtMCFaih+sVRCNAxgg+yMIIPrgIBATCBhjBy
# MQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3
# d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBTSEEyIEFzc3VyZWQg
# SUQgQ29kZSBTaWduaW5nIENBAhALTIJyAKtH3xTtbI8ZUVgmMA0GCWCGSAFlAwQC
# AQUAoHwwEAYKKwYBBAGCNwIBDDECMAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcC
# AQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIE
# IIZnoPXFudacYWk14CDUYxYBjaot0BK9YXXJNQd3EcuGMA0GCSqGSIb3DQEBAQUA
# BIIBAJB3czQh0k6AKBQxDeCGAbTjOwh4k3qhwYl89zh2us8dgLextt+4Ipak7UXU
# pOyeS45AD8HD02c5rPK1+yZqtlZC5mtrUXKaO71gln00MPnfq5knL3SnMGRHzGdk
# LP1MszXxBoQUz5J0c5NWL2SQ+0R458oZO6Zp4CtwO8r3kU8/dePgGlH4M3Ihxdjn
# sOx8Hj4O4sd9ueJrEtkTKGaN9I5DVxoGMhHAwFwmJqaaWHAsYcrbV6lJm+p8lM9R
# P0zY/Uzb7v5oMPvoY4cf3U1RH19AdvJCBZoBsW6ni21DVQqX+UVCs+YSOicV1vtF
# BIvXAlcE0GFs6jBCwaSmKIdcuJKhgg1+MIINegYKKwYBBAGCNwMDATGCDWowgg1m
# BgkqhkiG9w0BBwKggg1XMIINUwIBAzEPMA0GCWCGSAFlAwQCAQUAMHgGCyqGSIb3
# DQEJEAEEoGkEZzBlAgEBBglghkgBhv1sBwEwMTANBglghkgBZQMEAgEFAAQgLe/i
# IDSK92JWWkxIQbUFaptVhCHJous4eYD1/h8erwECEQCgMtEbgvRkTtK4ubAOSRiA
# GA8yMDIxMDYyNTAwMzkzOVqgggo3MIIE/jCCA+agAwIBAgIQDUJK4L46iP9gQCHO
# FADw3TANBgkqhkiG9w0BAQsFADByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGln
# aUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhE
# aWdpQ2VydCBTSEEyIEFzc3VyZWQgSUQgVGltZXN0YW1waW5nIENBMB4XDTIxMDEw
# MTAwMDAwMFoXDTMxMDEwNjAwMDAwMFowSDELMAkGA1UEBhMCVVMxFzAVBgNVBAoT
# DkRpZ2lDZXJ0LCBJbmMuMSAwHgYDVQQDExdEaWdpQ2VydCBUaW1lc3RhbXAgMjAy
# MTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMLmYYRnxYr1DQikRcpj
# a1HXOhFCvQp1dU2UtAxQtSYQ/h3Ib5FrDJbnGlxI70Tlv5thzRWRYlq4/2cLnGP9
# NmqB+in43Stwhd4CGPN4bbx9+cdtCT2+anaH6Yq9+IRdHnbJ5MZ2djpT0dHTWjaP
# xqPhLxs6t2HWc+xObTOKfF1FLUuxUOZBOjdWhtyTI433UCXoZObd048vV7WHIOsO
# jizVI9r0TXhG4wODMSlKXAwxikqMiMX3MFr5FK8VX2xDSQn9JiNT9o1j6BqrW7Ed
# MMKbaYK02/xWVLwfoYervnpbCiAvSwnJlaeNsvrWY4tOpXIc7p96AXP4Gdb+DUmE
# vQECAwEAAaOCAbgwggG0MA4GA1UdDwEB/wQEAwIHgDAMBgNVHRMBAf8EAjAAMBYG
# A1UdJQEB/wQMMAoGCCsGAQUFBwMIMEEGA1UdIAQ6MDgwNgYJYIZIAYb9bAcBMCkw
# JwYIKwYBBQUHAgEWG2h0dHA6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAfBgNVHSME
# GDAWgBT0tuEgHf4prtLkYaWyoiWyyBc1bjAdBgNVHQ4EFgQUNkSGjqS6sGa+vCgt
# HUQ23eNqerwwcQYDVR0fBGowaDAyoDCgLoYsaHR0cDovL2NybDMuZGlnaWNlcnQu
# Y29tL3NoYTItYXNzdXJlZC10cy5jcmwwMqAwoC6GLGh0dHA6Ly9jcmw0LmRpZ2lj
# ZXJ0LmNvbS9zaGEyLWFzc3VyZWQtdHMuY3JsMIGFBggrBgEFBQcBAQR5MHcwJAYI
# KwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBPBggrBgEFBQcwAoZD
# aHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0U0hBMkFzc3VyZWRJ
# RFRpbWVzdGFtcGluZ0NBLmNydDANBgkqhkiG9w0BAQsFAAOCAQEASBzctemaI7zn
# GucgDo5nRv1CclF0CiNHo6uS0iXEcFm+FKDlJ4GlTRQVGQd58NEEw4bZO73+RAJm
# Te1ppA/2uHDPYuj1UUp4eTZ6J7fz51Kfk6ftQ55757TdQSKJ+4eiRgNO/PT+t2R3
# Y18jUmmDgvoaU+2QzI2hF3MN9PNlOXBL85zWenvaDLw9MtAby/Vh/HUIAHa8gQ74
# wOFcz8QRcucbZEnYIpp1FUL1LTI4gdr0YKK6tFL7XOBhJCVPst/JKahzQ1HavWPW
# H1ub9y4bTxMd90oNcX6Xt/Q/hOvB46NJofrOp79Wz7pZdmGJX36ntI5nePk2mOHL
# KNpbh6aKLzCCBTEwggQZoAMCAQICEAqhJdbWMht+QeQF2jaXwhUwDQYJKoZIhvcN
# AQELBQAwZTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcG
# A1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEkMCIGA1UEAxMbRGlnaUNlcnQgQXNzdXJl
# ZCBJRCBSb290IENBMB4XDTE2MDEwNzEyMDAwMFoXDTMxMDEwNzEyMDAwMFowcjEL
# MAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3
# LmRpZ2ljZXJ0LmNvbTExMC8GA1UEAxMoRGlnaUNlcnQgU0hBMiBBc3N1cmVkIElE
# IFRpbWVzdGFtcGluZyBDQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEB
# AL3QMu5LzY9/3am6gpnFOVQoV7YjSsQOB0UzURB90Pl9TWh+57ag9I2ziOSXv2Mh
# kJi/E7xX08PhfgjWahQAOPcuHjvuzKb2Mln+X2U/4Jvr40ZHBhpVfgsnfsCi9aDg
# 3iI/Dv9+lfvzo7oiPhisEeTwmQNtO4V8CdPuXciaC1TjqAlxa+DPIhAPdc9xck4K
# rd9AOly3UeGheRTGTSQjMF287DxgaqwvB8z98OpH2YhQXv1mblZhJymJhFHmgudG
# UP2UKiyn5HU+upgPhH+fMRTWrdXyZMt7HgXQhBlyF/EXBu89zdZN7wZC/aJTKk+F
# HcQdPK/P2qwQ9d2srOlW/5MCAwEAAaOCAc4wggHKMB0GA1UdDgQWBBT0tuEgHf4p
# rtLkYaWyoiWyyBc1bjAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzAS
# BgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggr
# BgEFBQcDCDB5BggrBgEFBQcBAQRtMGswJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3Nw
# LmRpZ2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3aHR0cDovL2NhY2VydHMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNydDCBgQYDVR0fBHoweDA6
# oDigNoY0aHR0cDovL2NybDQuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElE
# Um9vdENBLmNybDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lD
# ZXJ0QXNzdXJlZElEUm9vdENBLmNybDBQBgNVHSAESTBHMDgGCmCGSAGG/WwAAgQw
# KjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzALBglg
# hkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggEBAHGVEulRh1Zpze/d2nyqY3qzeM8G
# N0CE70uEv8rPAwL9xafDDiBCLK938ysfDCFaKrcFNB1qrpn4J6JmvwmqYN92pDqT
# D/iy0dh8GWLoXoIlHsS6HHssIeLWWywUNUMEaLLbdQLgcseY1jxk5R9IEBhfiThh
# TWJGJIdjjJFSLK8pieV4H9YLFKWA1xJHcLN11ZOFk362kmf7U2GJqPVrlsD0WGkN
# fMgBsbkodbeZY4UijGHKeZR+WfyMD+NvtQEmtmyl7odRIeRYYJu6DC0rbaLEfrvE
# JStHAgh8Sa4TtuF8QkIoxhhWz0E0tmZdtnR79VYzIi8iNrJLokqV2PWmjlIxggKG
# MIICggIBATCBhjByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5j
# MRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBT
# SEEyIEFzc3VyZWQgSUQgVGltZXN0YW1waW5nIENBAhANQkrgvjqI/2BAIc4UAPDd
# MA0GCWCGSAFlAwQCAQUAoIHRMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAc
# BgkqhkiG9w0BCQUxDxcNMjEwNjI1MDAzOTM5WjArBgsqhkiG9w0BCRACDDEcMBow
# GDAWBBTh14Ko4ZG+72vKFpG1qrSUpiSb8zAvBgkqhkiG9w0BCQQxIgQgMJdxT2zL
# za+PdE0qudTEjUjTAXfc4YG5ZogkVB++v0wwNwYLKoZIhvcNAQkQAi8xKDAmMCQw
# IgQgsxCQBrwK2YMHkVcp4EQDQVyD4ykrYU8mlkyNNXHs9akwDQYJKoZIhvcNAQEB
# BQAEggEAd0m1XTvVCJQhPJwFa6eGokdAcLGJFDCWX17/ebnHfoILYnIu3L7B0nBN
# QqHpRWlT8E//2I+E8if2qwOzxShKSb1E6DQdq5svWZoX3MYvJ3XufDSHIIqc6WwW
# zjtT7ySDLW48k+2GppZo0YUFnSUfUJ91ttKPpnuW7hzqd3z+lu0Ajc3sc41CrQ/S
# eJ870uBN3E+ayqdx2vZtIdsHjF13EkIC+BYbbIem/OUEKXRW3W5x3WiLNpHphp78
# wuJlSBg+IyAtPQNPb4QqgAVBaTIg1KG5yPaIKvrdt4WGF5VaBnXoX5CixnzzvSIA
# cyn9FvdaU1sbgDiaNhLoi5ymeTBfzQ==
# SIG # End signature block
